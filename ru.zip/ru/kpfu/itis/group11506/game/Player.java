package ru.kpfu.itis.group11506.game;

public abstract class Player {
	
	//задание абстрктного метода выбора фигуры;
	public abstract figure showFigure();
}
