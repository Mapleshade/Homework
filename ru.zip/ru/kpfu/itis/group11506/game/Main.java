package ru.kpfu.itis.group11506.game;

public class Main {

	public static void main(String[] args) {
		
		//старт игры;
		Game game = new Game();
		game.start(1000);

	}

}
